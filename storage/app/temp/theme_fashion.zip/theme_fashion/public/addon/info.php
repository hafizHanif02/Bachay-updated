<?php return array (
  'software_id' => '0001',
  'name' => 'Lifestyle Theme',
  'is_active' => 0,
  'purchase_code' => '',
  'username' => '',
  'image' => 'fashion_theme.png',
);
