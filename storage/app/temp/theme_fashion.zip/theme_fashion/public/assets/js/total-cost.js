  "use strict";
    $('.checkout_action').on('click', function () {
        checkout();
    });
