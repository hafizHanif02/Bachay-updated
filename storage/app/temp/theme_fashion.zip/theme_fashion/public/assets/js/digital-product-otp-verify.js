"use strict";
$('.download_resend_otp_verify').on('click', function () {
    download_resend_otp_verify();
});

$('.download_otp_verify').on('click', function () {
    download_otp_verify();
});
