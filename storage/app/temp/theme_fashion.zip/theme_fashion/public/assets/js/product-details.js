"use strict";

$(document).ready(function(){
    getVariantPrice();
});
