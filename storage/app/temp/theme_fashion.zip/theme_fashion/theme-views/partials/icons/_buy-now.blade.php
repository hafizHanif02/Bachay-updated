<svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M15.8074 13.5967H3.2149L3.1474 13.9717C2.9299 15.8167 3.4999 17.3242 6.1249 17.3242H12.8674C15.4999 17.3242 16.0699 15.8167 15.8449 13.9717L15.1699 8.34672C14.9974 6.89172 14.7424 5.69922 12.1924 5.69922H6.7924C4.2424 5.69922 3.9874 6.89172 3.8149 8.34672L3.5749 10.3492L3.50739 10.8967" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
    <path d="M6.5 6.82422V4.19922C6.5 3.07422 7.25 2.32422 8.375 2.32422H10.625C11.75 2.32422 12.5 3.07422 12.5 4.19922V6.82422" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
