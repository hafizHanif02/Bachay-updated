<div class="modal fade" id="quickViewModal" tabindex="-1" aria-labelledby="quickview-modal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content" id="quickViewModal_content">

        </div>
    </div>
</div>
