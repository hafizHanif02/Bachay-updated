@extends('theme-views.layouts.app')

@section('title', translate('blank'))

@push('css_or_js')

@endpush

@section('content')

@endsection

@push('script')

@endpush
